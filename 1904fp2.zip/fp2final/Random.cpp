#include "Random.h"


int getRand(int LIMIt) {
	return rand() % LIMIt;
}