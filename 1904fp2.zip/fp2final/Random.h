//#pragma once
#ifndef RANDOM_H
#define RANDOM_H
#include <iomanip>  


int getRand(int LIMITE);
//Costes: O(n) siendo n el numero de fichas en la jugada

#endif // !RANDOM_H

